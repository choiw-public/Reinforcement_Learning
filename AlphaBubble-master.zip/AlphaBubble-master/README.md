# AlphaBubble
Deep reinforcement learning applied to the game Bubble Shooter
